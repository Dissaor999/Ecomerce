 <!-- main-footer -->
<footer class="main-footer">

<strong>Copyright &copy; 2017 <a href="#">Tutoriales a tu Alcance</a>.</strong> Todos los derechos reservados.

</footer>
<!-- main-footer -->