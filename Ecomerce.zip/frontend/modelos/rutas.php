<?php

class Ruta{

	/*=============================================
	RUTA LADO DEL CLIENTE
	=============================================*/	

	public static function ctrRuta(){

		return "http://ecomerce.test:8080/frontend/";
	
	}

	/*=============================================
	RUTA LADO DEL SERVIDOR
	=============================================*/	

	public static function ctrRutaServidor(){

		return "http://ecomerce.test:8080/backend/";
	
	}

}