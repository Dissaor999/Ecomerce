<!--=====================================
404
======================================-->      
<div class="container">

<div class="row">
  
  <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 text-center error404">
               
    <h1><small>CANCELADO</small></h1>
    
    <h2>Oops! La compra ha sido cancelada</h2>

  </div>

</div>

</div>