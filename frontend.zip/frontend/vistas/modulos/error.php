<!--=====================================
ERROR
======================================--> 
<div class="container">

<div class="row">
  
  <div class="col-xs-12 text-center error404">
               
    <h1><small>ERROR</small></h1>
    
    <h2>Oops! No se pudo ejecutar la compra, vuelva a intentarlo</h2>

  </div>

</div>

</div>